﻿using System;

namespace VC_SAP.Util
{
    internal class CONFIG_SAP
    {
        //public String CLIENT { get; set; }
        public String USER { get; set; }
        public String PASSWD { get; set; }
        public String LANG { get; set; }
        public String ASHOST { get; set; }
        public String SYSNR { get; set; }
    }
}
