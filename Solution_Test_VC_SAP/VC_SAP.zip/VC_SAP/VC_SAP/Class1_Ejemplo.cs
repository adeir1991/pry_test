﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VC_SAP
{
    class Class1_Ejemplo
    {
        string va = "hola";
    }
}
